---
"@fuel-ts/abi-coder": patch
"@fuel-ts/abi-typegen": patch
"@fuel-ts/account": patch
"@fuel-ts/address": patch
"@fuel-ts/contract": patch
"@fuel-ts/crypto": patch
"@fuel-ts/errors": patch
"fuels": patch
"@fuel-ts/hasher": patch
"@fuel-ts/interfaces": patch
"@fuel-ts/math": patch
"@fuel-ts/merkle": patch
"@fuel-ts/program": patch
"@fuel-ts/script": patch
"@fuel-ts/transactions": patch
"@fuel-ts/utils": patch
"@fuel-ts/versions": patch
---

Use interal utilities for arrayify, hexlify, concat and BytesLike
