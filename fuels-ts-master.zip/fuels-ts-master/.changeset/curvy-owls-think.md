---
"@fuel-ts/transactions": patch
---

Fixed encoding/decoding of specific parts of a transaction and its inputs
