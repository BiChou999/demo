---
"create-fuels": minor
---

feat: add new options to the `create-fuels` CLI:

-c, --contract Include contract program
-p, --predicate Include predicate program
-s, --script Include script program
--pnpm Use pnpm as the package manager
--npm Use npm as the package manager
-cs, -cp, -sp, -cps Shorthand to include combination of contract, script and predicate programs
-h, --help display help for command
