---
"@fuel-ts/account": patch
"@fuel-ts/errors": patch
"@fuel-ts/program": patch
---

exports InvocationCallResult
