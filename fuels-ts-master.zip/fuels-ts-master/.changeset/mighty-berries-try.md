---
"@fuel-ts/abi-coder": minor
"@fuel-ts/errors": minor
---

Introduce the v1 encoding scheme and use correct file naming conventions for `@fuel-ts/abi-coder`
