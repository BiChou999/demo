---
"@fuel-ts/account": patch
---

remove unused connectors types
