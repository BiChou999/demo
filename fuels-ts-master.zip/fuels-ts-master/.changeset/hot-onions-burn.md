---
"fuels": patch
---

Adding new `forcBuildFlags` property to `fuels` config
