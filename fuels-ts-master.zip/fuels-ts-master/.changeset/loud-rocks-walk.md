---
"@fuel-ts/account": patch
---

feat: migrate over @fuels/assets package into the TS SDK
