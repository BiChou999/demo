import { index } from '@internal/tsup';

export default index;
