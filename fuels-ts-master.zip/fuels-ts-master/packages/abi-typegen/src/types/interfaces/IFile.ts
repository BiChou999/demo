export interface IFile {
  path: string;
  contents: string;
}
