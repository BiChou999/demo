export enum ProgramTypeEnum {
  CONTRACT = 'contract',
  SCRIPT = 'script',
  PREDICATE = 'predicate',
}
