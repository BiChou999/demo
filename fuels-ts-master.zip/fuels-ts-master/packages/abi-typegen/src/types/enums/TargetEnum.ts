export enum TargetEnum {
  INPUT = 'input',
  OUTPUT = 'output',
}
