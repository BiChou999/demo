import { tsupDefaults } from './src';

export default {
  ...tsupDefaults,
  entry: ['src/index.ts'],
};
