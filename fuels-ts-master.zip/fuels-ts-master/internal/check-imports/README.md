This package validates importing all other packages.

It ensures all packages are ok and should `build` successfully.

If `build` fails, there might be something broken or misconfigured.
