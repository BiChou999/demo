This package validates our environment testing setup.

It ensures that environment specific functionalities should be supported by the SDK.

If one of these tests fails, it may indicate that an environment is configured incorrectly.
