<script setup>
  import { data } from '../versions.data'
  const { forc, fuels, fuelCore } = data
</script>

# The Fuel TypeScript SDK API Documentation

<br/>

#### Version Notice: Docs generated using Fuels `v{{fuels}}`, Fuel Core `v{{fuelCore}}`, Sway `v{{forc}}`, and Forc `v{{forc}}`.
