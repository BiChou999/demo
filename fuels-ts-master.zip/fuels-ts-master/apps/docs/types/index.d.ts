declare module 'vitepress-plugin-search';
