# Getting Messages

You can use the `getMessages` method to retrieve a list of messages from the blockchain.

<<< @/../../../packages/fuel-gauge/src/coverage-contract.test.ts#Message-getMessages{ts:line-numbers}
