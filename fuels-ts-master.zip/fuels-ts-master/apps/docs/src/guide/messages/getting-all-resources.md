# Getting All Resources

You can use the `getResourcesToSpend` method to retrieve a list of all the resources (coins + assets) that can be spent by a given address.

<<< @/../../../packages/account/src/account.test.ts#Message-getResourcesToSpend{ts:line-numbers}
