# About

This is a simple demo composed by:

- `/contract` — Sway contract
- `/src` — Typescript project

# Building

```shell
pnpm build
```

> **Note** See the scripts in `package.json` for detailed info.

This will:

1.  Compile Sway contract
1.  Generate types for it, inside `src/generated-types`
