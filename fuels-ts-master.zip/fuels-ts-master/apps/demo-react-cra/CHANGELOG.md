# demo-react-cra

## 0.1.29

## 0.1.28

## 0.1.27

## 0.1.26

## 0.1.25

## 0.1.24

## 0.1.23

## 0.1.22

## 0.1.21

## 0.1.20

## 0.1.19

## 0.1.18

## 0.1.17

## 0.1.16

## 0.1.15

## 0.1.14

## 0.1.13

### Patch Changes

- Upgrading vm/wasm libs, by [@arboleya](https://github.com/arboleya) (See [#1226](https://github.com/FuelLabs/fuels-ts/pull/1226))

## 0.1.12

## 0.1.11

## 0.1.10

## 0.1.9

## 0.1.8

### Patch Changes

- Adding WASM integration for `@fuels/vm-asm`, by [@camsjams](https://github.com/camsjams) (See [#1164](https://github.com/FuelLabs/fuels-ts/pull/1164))

## 0.1.7

## 0.1.6

## 0.1.5

## 0.1.4

## 0.1.3

### Patch Changes

- Adding WASM integration for `@fuels/vm-asm`, by [@arboleya](https://github.com/arboleya) (See [#1080](https://github.com/FuelLabs/fuels-ts/pull/1080))
- `NativeAssetId` has been renamed to `BaseAssetId` for better clarity and consistency with the Rust SDK, by [@Dhaiwat10](https://github.com/Dhaiwat10) (See [#1121](https://github.com/FuelLabs/fuels-ts/pull/1121))

## 0.1.2

## 0.1.1

### Patch Changes

- Adding demo apps and validating integration with external tools and bundlers, by [@arboleya](https://github.com/arboleya) (See [#1056](https://github.com/FuelLabs/fuels-ts/pull/1056))

## 0.1.1

### Patch Changes

- Adding demo apps and validating integration with external tools and bundlers, by [@arboleya](https://github.com/arboleya) (See [#1056](https://github.com/FuelLabs/fuels-ts/pull/1056))
